<?php

// we don't actually save the file, since this is just a demo - we just say that we did

echo '1';

?>